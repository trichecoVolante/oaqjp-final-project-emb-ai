from .emotion_detection import emotion_detector
